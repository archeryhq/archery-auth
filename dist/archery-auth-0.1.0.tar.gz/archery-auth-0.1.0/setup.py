# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['archery_auth',
 'archery_auth.parsers',
 'archery_auth.parsers.auths',
 'archery_auth.sql',
 'archery_auth.sql.controllers',
 'archery_auth.sql.models']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.4.5,<2.0.0',
 'archery-secret @ git+https://github.com/archeryhq/archery-secret.git@main',
 'psycopg2>=2.8.6,<3.0.0']

setup_kwargs = {
    'name': 'archery-auth',
    'version': '0.1.0',
    'description': 'Persons authorization information manager.',
    'long_description': '# Archery Auth\nPersons authorization information manager.\n\n[Github](https://github.com/archeryhq/archery-auth)\n\n## Environment\n\nBefore using the module, it is necessary to create the following environment variables:\n\n* ARCHERY_PERSON_SECRET - This key must be 32 url-safe base64-encoded bytes.\n* ARCHERY_PERSON_SQL_URI - PostgreSQL URL.\n\nThese variables can be stored within an .env file.\n\n## How to use\n\nThere are two related tables:\n\n* Roles - Authorization levels.\n\n* Auth - Responsible from personal data.\n\nShow the [notebook](https://github.com/archeryhq/archery-auth/blob/main/Tests.ipynb)!*\n',
    'author': 'Enio Climaco Sales Junior',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/archeryhq/archery-auth',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
